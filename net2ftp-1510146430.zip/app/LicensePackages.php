<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LicensePackages extends Model
{
    protected $table = 'license_packages';
    protected $fillable = ['name','information','price','image'];
    public $timestamps = false;

}
