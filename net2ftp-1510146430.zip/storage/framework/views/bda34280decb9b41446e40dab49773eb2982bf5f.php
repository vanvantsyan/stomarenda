<?php $__env->startSection('content'); ?>
    <h2>Оборудование</h2>
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>

            <?php endif; ?>
            <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Добавить оборудование</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" method="POST" action="<?php echo e(route('add.products')); ?>" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="exampleInputName">Название</label>
                                <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                                <input type="text" name="name" class="form-control" id="exampleInputName"
                                       placeholder="Лампа для отбеливания">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputModel">Модель</label>
                                <input type="text" name="model" class="form-control" id="exampleInputModel"
                                       placeholder="Lux  25-10">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPrice">Цена</label>
                                <input type="number" name="price" class="form-control" id="exampleInputPrice"
                                       placeholder="3500">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputImage">Главное изображение </label>
                                <small>Рекомендуемый размер (300 x 260)</small>
                                <input type="file" name="image" id="exampleInputImage">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputMainImage">Другие Изображения </label>
                                <small>Рекомендуемый размер (300 x 260)</small>
                                <input type="file" name="images[]" id="exampleInputMainImage" multiple>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputFiles">Файлы </label>
                                <input type="file" name="files[]" id="exampleInputFiles" multiple>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputGroup">Группа</label>
                                <select class="form-control" name="group">
                                    <option>--Выберите группу--</option>
                                    <?php $__currentLoopData = $prodGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($prodGroup['id']); ?>"><?php echo e($prodGroup['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputGroup">Производитель</label>
                                <select class="form-control" name="manufacturer">
                                    <option>--Выберите производителя--</option>
                                    <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($manufacturer['id']); ?>"><?php echo e($manufacturer['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputMetadesc">Мета-Описание</label>
                                <input type="text" name="meta_desc" class="form-control" id="exampleInputMetadesc"
                                       placeholder="Описание продукта">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputMetakeys">Мета-key</label>
                                <input type="text" name="meta_key" class="form-control" id="exampleInputMetakeys"
                                       placeholder="Ключевые слова">
                            </div>
                            <div class="form-group">
                                <label for="froala-editor">Описание</label>
                                <textarea id="froala-editor" class="form-control" name="description"
                                          placeholder="Описание продукта"></textarea>

                            </div>
                            <div class="form-group">
                                <label for="exampleInputAttributes"> Характеристика </label>
                                <textarea class="form-control" name="attributes" id="froala-editor"
                                          placeholder="Характеристика продукта"></textarea>
                            </div>
                            
                        </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Добавить</button>
                </div>
                </form>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>