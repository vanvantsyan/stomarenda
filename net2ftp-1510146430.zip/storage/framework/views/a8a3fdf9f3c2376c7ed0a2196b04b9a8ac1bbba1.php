<?php $__env->startSection('content'); ?>
 <!-- Main content -->
    <section class="content">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>

        <?php endif; ?>
            <div class="row">
            <div class="box-header">
                <h2 class="head_title"> Группы продуктов</h2>
                <a href="<?php echo e(route( 'create.productGroup' )); ?>"
                   type="submit" class="btn btn-primary link_to_add">Создать</a>
            </div>
            <div class="box-body">
                <table class="table table-condensed">
                    <tr style="color:#269abc">
                        <th style="width: 10px">ID</th>
                        <th>Название</th>
                        <th style="width: 80px"></th>
                    </tr>
                    <?php if($productGroups): ?>
                        <?php $__currentLoopData = $productGroups->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td>
                                    <?php echo e($productGroup->id); ?>

                                </td>
                                <td>
                                    <b>
                                        <?php echo e($productGroup->name); ?>

                                    </b>
                                </td>

                                <td class="text-center">
                                    <a href="<?php echo e(route( 'edit.productGroup' , ['id'=>$productGroup->id])); ?>"
                                       type="submit" class="btn btn-xs btn-primary" style="width:22px">
                                        <div class="fa fa-edit"></div>
                                    </a>
                                    <a href="<?php echo e(route( 'delete.productGroup' , ['id'=>$productGroup->id])); ?>"
                                       type="submit" class="btn btn-xs btn-danger confirm">
                                        <div class="fa fa-trash-o "></div>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </table>
            </div>

            </div>

  	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>