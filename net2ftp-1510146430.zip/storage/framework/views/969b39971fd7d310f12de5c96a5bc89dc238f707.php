

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="panel-heading">
            <h2 class="head_title">Заявки на звонки</h2>
        </div>
        <div class="col-sm-12">
            <?php if($callQueries): ?>
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Список</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body no-padding">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success')); ?>

                            </div>

                        <?php endif; ?>
                        <table class="table table-condensed">
                            <tr style="color:#269abc">
                                <th style="width: 10px">ID</th>
                                <th>Имя</th>
                                <th>Номер тел.</th>
                                <th>Дата</th>
                                <th>Статус</th>
                                <th style="width: 40px">Сделано</th>
                            </tr>
                            <?php $__currentLoopData = $callQueries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $callQuery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td>
                                        <?php echo e($callQuery['id']); ?>

                                    </td>
                                    <td>
                                        <b>
                                            <?php echo e($callQuery['name']); ?>

                                        </b>
                                    </td>
                                    <td>
                                        <?php echo e($callQuery['tel']); ?>

                                    </td>
                                    <td>
                                        <?php echo e($callQuery['created_at']); ?>

                                    </td>
                                    <?php
                                    $callButton = 'fa-square-o';
                                    $color = 'red';
                                    if ($callQuery['status'] == '1') {
                                        $color = 'green';
                                        $callButton = 'fa-check-square-o';
                                    }
                                    ?>
                                    <td style="color:<?php echo e($color); ?>;font-size: 16px;">

                                        <div class="fa <?php echo e($callButton); ?>"></div>
                                    </td>

                                    <td class="text-right">
                                        <?php
                                        $callButton = 'fa-minus';
                                        $status = 'danger';
                                        if ($callQuery['status'] == '0') {
                                            $callButton = 'fa-plus';
                                            $status = 'success';
                                        }
                                        ?>
                                        <a href="<?php echo e(route( 'update.callQuery' , ['id'=>$callQuery['id']])); ?>"
                                           type="submit" class="btn btn-xs btn-<?php echo e($status); ?>" style="width:22px">
                                            <div class="fa <?php echo e($callButton); ?> "></div>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>
                </div>

            <?php endif; ?>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function () {
            $('.fa-check-square-o').on('click', function () {

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>