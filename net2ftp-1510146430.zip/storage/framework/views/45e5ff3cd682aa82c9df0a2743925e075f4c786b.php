<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/')); ?>">Главная</a></li>
                    <li><a>Оборудование для лицензирования</a></li>
                </ol>
            </div>
        </div>
    </div>
    <section class="physio" style="padding:10px 0 60px 0">

        <div class="container">
            <div class="row related-products-section">
                <div class="col-md-12">
                    <h1> Оборудование для лицензирования</h1>
                </div>
                <div class="physio-container-wrap">
                        <?php $__currentLoopData = $licenseProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licenseProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a  href="<?php echo e(url('licenseProduct/'.$licenseProduct->id)); ?>">
                            <div class="col-md-3 col-sm-6 padnone">
                                <div class="related-product-container bgrc-<?php echo e($licenseProduct->color); ?>" style="height: 280px;">
                                    <div class="related-img-container" style="height: 175px;">
                                        <img src="<?php echo e(URL::to("$layout_path/images-licenseprod/".$licenseProduct->image)); ?>"
                                             alt="<?php echo e($licenseProduct->model); ?>">
                                    </div>
                                    <div class="physio-text-container related-text-container text-center" style="    height: auto;">
                                        <h2  style="color:grey"><?php echo e($licenseProduct->type_name); ?>

                                        </h2>
                                        <span class="read-more" >Подробнее</span><i class="fa fa-angle-right"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site_layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>