<?php $__env->startSection('content'); ?>

    <style>


        .full-height {
            height: 500px;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 36px;
            padding: 20px;
        }
    </style>

    <div class="flex-center position-ref full-height">
        <div class="content">
            <div class="title" style="color:grey">
                Извините , вами запрашиваемая страница не найдена.
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('site_layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>