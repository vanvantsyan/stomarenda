<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>
        <div class="row">
            <div class="panel-heading">
                <h2 class="head_title">Оборудование</h2>
                <a href="<?php echo e(route( 'create.product' )); ?>"
                   type="submit" class="btn btn-primary link_to_add">Создать</a>
            </div>
            <div class="col-xs-12">

                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Список</h3>
                    </div>

                    <div class="box-body table-responsive no-padding">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Название</th>
                                <th>Модель</th>
                                <th>Цена</th>
                                <th>Производитель</th>
                                <th>Группа</th>
                                <th></th>
                                <!-- <th>Изображение</th> -->
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product->id); ?></td>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e($product->model); ?></td>
                                    <td><?php echo e($product->price); ?></td>
                                    <td><?php echo e($product->manufacturer); ?></td>
                                    <td><?php echo e($product->groups); ?></td>
                                <!--  <td>
                                                                      <img src="<?php echo e(url('public/images-products/'.$product->image)); ?>" class="admin_images">
                                                                    </td> -->
                                    <td class="text-center">
                                        <a href="<?php echo e(route( 'edit.product' , ['id'=>$product->id])); ?>"
                                           type="submit" class="btn btn-primary btn-xs" style="width:22px">
                                            <div class="fa fa-edit"></div>
                                        </a>
                                        <a href="<?php echo e(route( 'delete.product' , ['id'=>$product->id])); ?>"
                                           type="submit" class="btn btn-danger btn-xs confirm">
                                            <div class="fa fa-trash-o "></div>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.box-body -->
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>