<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/')); ?>">Главная</a></li>
                    <li class="active"><span><?php echo e($group->name); ?></span></li>
                </ol>
            </div>
        </div>
    </div>
    <section class="physio">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo e($group->name); ?>  </h1>
                </div>
            </div>
            <div class="row">
                <div class="physio-container-wrap">
                    <div class="physio-bgr-wrap">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-sm-6 padnone">
                                <div class="physio-container bgrc-dark">
                                    <a href="<?php echo e(url('product/'.$product->id)); ?>">
                                        <div class="physio-img-container"><img
                                                    src="<?php echo e(URL::to("$layout_path/images-products/".$product->image)); ?>"
                                                    alt="<?php echo e($product->meta_key); ?>"></div>
                                        <div class="physio-text-container">
                                            <h3><?php echo e($product->name); ?> <span><?php echo e($product->model); ?></span></h3>
                                            <div class="producer"><?php echo e($product->manufacturer); ?>

                                                , <?php echo e($product->country); ?></div>
                                            <div class="lease-time">Аренда в день</div>
                                            <div class="lease-price"><?php echo e($product->price); ?> <i class="fa fa-rub"></i></div>
                                            <span class="read-more" style="float:right">Подробнее <i
                                                        class="fa fa-angle-right"></i></span>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row related-products-section">
                <div class="col-md-12">
                    <h1>сопутствующие товары </h1>
                </div>
                <div class="physio-container-wrap">
                  
                    <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-sm-6 padnone">
                            <div class="related-product-container bgrc-<?php echo e($related_product->background); ?>">
                                <div class="related-img-container">
                                    <img src="<?php echo e(URL::to("$layout_path/images-related/".$related_product->image)); ?>"
                                         alt="<?php echo e($related_product->model); ?>">
                                </div>
                                <div class="physio-text-container related-text-container">
                                    <h3><?php echo e($related_product->name); ?> <span><?php echo e($related_product->model); ?> </span><span
                                                class="quantity">(1 шт)</span>
                                    </h3>
                                    <div class="producer"><?php echo e($related_product->manufacturer); ?>

                                        , <?php echo e($related_product->country); ?></div>
                                    <div class="lease-price">1000 <i class="fa fa-rub"></i></div>
                                    
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <section class="container companies-manufacturers">
            <div class="row">
                <div class="col-md-12">
                    <h1>КОМПАНИИ-ПРОИЗВОДИТЕЛИ  </h1>
                    <div class="owl-carousel">
                        <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img class="brand1"
                                 src="<?php echo e(URL::to("$layout_path/images-manuf/".$manufacturer->image)); ?>"
                                 alt="<?php echo e($manufacturer->name); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </section>
        <section class="container-fluid form"><img class="object-form-right"
                                                   src="<?php echo e(URL::to("$layout_path/front/img/general/object-form-right.png")); ?>"
                                                   alt="object">
            <div class="container">
                <div class="row">
                    <div class="form-left">
                        <div class="form-left-overlay"></div>
                        <img class="form-bgr"
                             src="<?php echo e(URL::to("$layout_path/front/img/content/advantages-bgr.jpg")); ?>"
                             alt="advantages-bgr">
                    </div>
                    <div class="col-md-6"></div>
                    <div class="col-md-6 form-right"><img class="object-form-left"
                                                          src="<?php echo e(URL::to("$layout_path/front/img/general/object-form-left.png")); ?>"
                                                          alt="object"><img class="form-pic"
                                                                            src="<?php echo e(URL::to("$layout_path/front/img/general/form-pic.png")); ?>"
                                                                            alt="photo">
                        <h1>Форма связи </h1>
                        <div class="form-right-desc">Для получения дополнительной информации, пожалуйста, заполните
                            форму и
                            мы обязательно с Вами свяжемся.
                        </div>
                        <div class="callquery_form" style="height: 100px">
                            <form id="form" action="<?php echo e(url('call')); ?>" method="POST">
                                <input class="form-input form-name" type="text" name="name" placeholder="Имя"
                                       pattern=".{3,20}" required>
                                <input class="form-input form-tel" type="text" name="tel" placeholder="Телефон"
                                       pattern="[0-9]{6,12}" required>
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button class="btn-blue" type="submit">Перезвоните мне</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site_layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>