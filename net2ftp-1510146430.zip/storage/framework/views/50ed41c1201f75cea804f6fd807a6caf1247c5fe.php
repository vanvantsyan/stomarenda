<?php $__env->startSection('content'); ?>
<h2>Lisence Packages</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>