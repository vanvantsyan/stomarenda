<?php $__env->startSection('content'); ?>
    <div>
        <h2 class="head_title">Отзывы</h2>
    </div>
    <div class="panel-body">

        <!-- right column -->
        <div class="col-sm-12">
            <?php if($feedback): ?>
                <div>

                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Список</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body no-padding">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                </div>

                            <?php endif; ?>
                            <table class="table table-condensed">
                                <tr style="color:#269abc">
                                    <th style="width: 10px">ID</th>
                                    <th>Имя</th>
                                    <th>Должность</th>
                                    <th>Комментарий</th>
                                    <th>Продукт</th>
                                    <th style="width: 80px"></th>
                                </tr>
                                <?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $feed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td>
                                            <?php echo e($feed['id']); ?>

                                        </td>
                                        <td>
                                            <b>
                                                <?php echo e($feed['username']); ?>

                                            </b>
                                        </td>
                                        <td>
                                            <?php echo e($feed['position']); ?>

                                        </td>
                                        <td>
                                            <?php echo e($feed['message']); ?>

                                        </td>
                                        <td>
                                            <?php echo e($feed['product']); ?>

                                        </td>

                                        <td class="text-right">

                                            <a href="<?php echo e(route( 'edit.feedback' , ['id'=>$feed['id']])); ?>"
                                               type="submit" class="btn btn-xs btn-primary" style="width:22px">
                                                <div class="fa fa-edit"></div>
                                            </a>
                                            <a href="<?php echo e(route( 'delete.feedback' , ['id'=>$feed['id']])); ?>"
                                               type="submit" class="btn btn-xs btn-danger confirm">
                                                <div class="fa fa-trash-o "></div>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>