

<?php $__env->startSection('content'); ?>
    <h2>Оборудование для лицензирования</h2>

    <div class="panel panel-default">
        <div class="panel-heading">Добавить оборудование</div>
        <div class="panel-body">

            <form action="<?php echo e(route('update.licenseProduct')); ?>" method="POST" enctype="multipart/form-data">
                <div class="col-sm-9">

                    <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                    <div class="form-group">
                        <label for="ProdLisName">Тип лицензии </label>
                        <input type="hidden" value="<?php echo e($products->id); ?>" name="id">
                        <input type="text" name="type_name" id="ProdLisName" class="form-control"
                               placeholder="Лицензия для..."
                               value="<?php echo e($products->type_name); ?>">
                    </div>
                    <div class="form-group">
                        <?php if($products->image): ?>
                            <div>
                                <img src="<?php echo e(url('public/images-licenseprod/'.$products->image)); ?>" class="admin_images">
                            </div>
                        <?php endif; ?>
                        <label for="exampleInputFile">Изменить изображение</label>
                        <input type="file" name="image" id="exampleInputFile">
                    </div>
                    <div class="form-group">
                        <label for="ProdLisDesc">Мета-Описание </label>
                        <input type="text" name="meta_desc" id="ProdLisDesc" class="form-control"
                               placeholder="Описание лицензирования" value="<?php echo e($products->meta_description); ?>">
                    </div>
                    <div class="form-group">
                        <label for="ProdLisKey">Мета-key </label>
                        <input type="text" name="meta_key" id="ProdLisKey" class="form-control"
                               placeholder="Ключевые слова" value="<?php echo e($products->meta_key); ?>">
                    </div>
                    <div id="education_fields">
                        <div class="col-sm-6 nopadding">
                            <div class="form-group">
                                <label for="name">Название </label>
                            </div>
                        </div>

                        <div class="col-sm-2 nopadding">
                            <div class="form-group">
                                <label for="name">Цена </label>
                            </div>
                        </div>

                        <div class="col-sm-2 nopadding">
                            <div class="form-group">
                                <label for="name">В наличии </label>
                            </div>
                        </div>

                        <div class="col-sm-2 nopadding">
                            <div class="form-group">
                                <label for="name">Добавить поле </label>
                            </div>
                        </div>
                    </div>
                    <div class="appform">
                        <?php $__currentLoopData = $license_product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-sm-6 nopadding">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="name[<?php echo e($key); ?>]" placeholder="Название"
                                           value="<?php echo e($product_info->name); ?>">
                                </div>
                            </div>
                            <div class="col-sm-2 nopadding">
                                <div class="form-group">
                                    <input type="number" class="form-control" name="price[<?php echo e($key); ?>]" placeholder="2500"
                                           step="100" min="0"
                                           value="<?php echo e($product_info->price); ?>">
                                </div>

                            </div>
                            <div class="col-sm-2 nopadding">
                                <div class="form-group">
                                    <input type="checkbox" class="have_checkbox" name="have[<?php echo e($key); ?>]"
                                           value="1" <?php echo e(($product_info->have == 1 ? "checked":"")); ?>>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <div class="col-sm-2 nopadding">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-btn">
                                        <button class="btn btn-success" type="button" onclick="education_fields();">
                                            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                    <button type="submit" class="btn btn-primary products_button">Сохранить</button>
                </div>
            </form>
        </div>

        <div class="clear"></div>


        <!-- Javascript -->
        <script type='text/javascript'>

            var room = "<?php echo count($license_product_info) ?>";

            function education_fields() {
                var divtest = "<div class=\"removeclass" + parseInt(room) + '" style="clear:both">';
                divtest +=
                    '<div class="col-sm-6 nopadding">' +
                    '<div class="form-group">' +
                    '<input type="text" class="form-control" name="name[' + room + ']" placeholder="Название">' +
                    '</div>' +
                    '</div>' +
                    '<div class="col-sm-2 nopadding">' +
                    '<div class="form-group">' +
                    '<input type="number" class="form-control" name="price[' + room + ']" placeholder="2500" step="100" min="0">' +
                    '</div>' +
                    '</div>' +
                    '<div class="col-sm-2 nopadding">' +
                    '<div class="form-group">' +
                    '<input type="checkbox"  class="have_checkbox" name="have[' + room + ']" value="1" >' +
                    '</div>' +
                    '</div>' +
                    '<div class="col-sm-2 nopadding">' +
                    '<div class="form-group">' +
                    '<div class="input-group">' +
                    '<div class="input-group-btn">' +
                    '<button class="btn btn-danger" type="button" onclick="remove_education_fields(' + room + ');">' +
                    '<span class="glyphicon glyphicon-minus" aria-hidden="true"></span>' +
                    '</button>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '<div class="clear"></div>';
                divtest += '</div>';
                $('.appform').append(divtest)
                room++;

            }

            function remove_education_fields(rid) {
                $('.removeclass' + rid).remove();
            }
        </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>