<?php $__env->startSection('content'); ?>
    <h2>Сопутствующие товары</h2>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if($relatedProduct): ?>
    <div class="panel panel-default">
        <div class="panel-heading">Редактировать</div>
        <div class="panel-body">

            <form action="<?php echo e(route('update.relatedProduct')); ?>" method="POST" enctype="multipart/form-data">
                <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                <input name="id" type="hidden" value="<?php echo e($relatedProduct->id); ?>"/>
                <div class="box-body">
                    <div class="form-group">
                        <label for="exampleInputName">Название </label>
                        <input type="text" name="name" class="form-control" id="exampleInputName" value="<?php echo e($relatedProduct->name); ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputModel">Модель </label>
                        <input type="text" name="model" class="form-control" id="exampleInputModel"
                               value="<?php echo e($relatedProduct->model); ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputProd">Оборудование </label>
                        <select name="group_id" class="form-control" id="exampleInputProd">
                            <option>--Выберите оборудование--</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($group->id); ?>" <?php echo e(($relatedProduct->group_id == $group->id ? "selected":"")); ?>><?php echo e($group->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputManuf">Производитель </label>
                        <select name="manufacturer_id" class="form-control" id="exampleInputManuf">
                            <option>--Выберите производителя--</option>
                            <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($manufacturer->id); ?>" <?php echo e(($relatedProduct->manufacturer_id == $manufacturer->id ? "selected":"")); ?>><?php echo e($manufacturer->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="exampleInputPrice">Цена </label>
                        <input type="number" name="price" step="100" min="0" class="form-control"
                               id="exampleInputPrice" placeholder="5000"  value="<?php echo e($relatedProduct->price); ?>">
                    </div>
                    <div class="form-group">
                        <div>
                            <img src="<?php echo e(url('public/images-related/'.$relatedProduct->image)); ?>" class="admin_images">
                        </div>
                        <label for="exampleInputFile">Изображение</label>
                        <input type="file" name="image" id="exampleInputFile">
                    </div>
                    <button type="submit" class="btn btn-primary products_button">Добавить</button>

                </div>

            </form>
        </div>

    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>