<?php $__env->startSection('content'); ?>
    <h2>Заказы</h2>
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
              <?php endif; ?>
                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(Session::get('error')); ?>

                    </div>
              <?php endif; ?>
            <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Редактировать </h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                        <div class="box-body">

                            <div class="row">
                                <form role="form" method="POST" action="<?php echo e(route('update.order')); ?>" enctype="multipart/form-data">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputName">Имя</label>
                                        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                                        <input name="id" type="hidden" value="<?php echo e($order->id); ?>"/>
                                        <input name="product_type" type="hidden" value="<?php echo e($order->product_type); ?>"/>
                                        <input type="text" name="name" value="<?php echo e($order->name); ?>"
                                               class="form-control"
                                               id="exampleInputName">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputModel">Телефон</label>
                                        <input type="text" name="tel" value="<?php echo e($order->tel); ?>"
                                               class="form-control"
                                               id="exampleInputModel">
                                    </div>
                                    <?php if($order->product_type == "0"): ?>
                                        <label for="examplePeriod">Срок аренды</label>
                                        <div class=" form-inline col-md-12">
                                            <div class="row" id="examplePeriod">
                                                <div class="col-md-6 no-padding ">
                                                    <label for="exampleInputFrom">С</label>
                                                    <input type="text" name="from_date" value="<?php echo e($order->from_date); ?>"
                                                           class="form-control admin_form_dates"
                                                           id="exampleInputFrom">
                                                </div>
                                                <div class="col-md-6 no-padding ">
                                                    <label for="exampleInputTo">До</label>
                                                    <input type="text" name="to_date" value="<?php echo e($order->to_date); ?>"
                                                           class="form-control admin_form_dates"
                                                           id="exampleInputTo ">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputTime">Время</label>

                                            <select class="form-control" name="time" id="exampleInputTime">
                                                <option value="09:00" <?php echo e($order->time == '09:00' ? 'selected' : ''); ?>>
                                                    09:00
                                                </option>
                                                <option value="10:00" <?php echo e($order->time == '10:00' ? 'selected' : ''); ?>>
                                                    10:00
                                                </option>
                                                <option value="11:00" <?php echo e($order->time == '11:00' ? 'selected' : ''); ?>>
                                                    11:00
                                                </option>
                                                <option value="12:00" <?php echo e($order->time == '12:00' ? 'selected' : ''); ?>>
                                                    12:00
                                                </option>
                                                <option value="13:00" <?php echo e($order->time == '13:00' ? 'selected' : ''); ?>>
                                                    13:00
                                                </option>
                                                <option value="14:00" <?php echo e($order->time == '14:00' ? 'selected' : ''); ?>>
                                                    14:00
                                                </option>
                                                <option value="15:00" <?php echo e($order->time == '15:00' ? 'selected' : ''); ?>>
                                                    15:00
                                                </option>
                                                <option value="16:00" <?php echo e($order->time == '16:00' ? 'selected' : ''); ?>>
                                                    16:00
                                                </option>
                                                <option value="17:00" <?php echo e($order->time == '17:00' ? 'selected' : ''); ?>>
                                                    17:00
                                                </option>
                                                <option value="18:00" <?php echo e($order->time == '18:00' ? 'selected' : ''); ?>>
                                                    18:00
                                                </option>
                                                <option value="19:00" <?php echo e($order->time == '19:00' ? 'selected' : ''); ?>>
                                                    19:00
                                                </option>
                                            </select>
                                        </div>
                                    <?php endif; ?>
                                    <div class="form-group">
                                        <label for="exampleInputModel">Название</label>
                                        <input readonly type="text" name="product_name" value="<?php echo e($order->product_name); ?>"
                                               class="form-control"
                                               id="exampleInputModel">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputRelPrice">Цена оборудований/пакета</label>
                                        <input type="number" min="0" step="100" name="product_price"
                                               value="<?php echo e($order->product_price); ?>"
                                               class="form-control"
                                               id="exampleInputRelPrice">
                                    </div>
                                    <?php if($order->product_type == '0'): ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label for="exampleInputCount">Соп.
                                                    товар: <?php echo e($order->related_product); ?></label>
                                                <div class="form-inline">
                                                    <input type="number" style="width:70px;" min="0"
                                                           name="related_count"
                                                           value="<?php echo e($order->related_count); ?>"
                                                           class="form-control "
                                                           id="exampleInputCount">
                                                    <small>(шт.)</small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputRelPrice">Цена сопутствующих товаров</label>
                                            <input type="number" min="0" step="100" name="related_price"
                                                   value="<?php echo e($order->related_price); ?>"
                                                   class="form-control"
                                                   id="exampleInputRelPrice">
                                        </div>
                                    <?php endif; ?>
                                    <div class="form-group">
                                        <label for="exampleInputPrice">Эл. почта</label>
                                        <input type="text" name="email" value="<?php echo e($order->email); ?>"
                                               class="form-control"
                                               id="exampleInputPrice">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputAddress">Адрес доставки</label>
                                        <input type="text" name="address" value="<?php echo e($order->address); ?>"
                                               class="form-control"
                                               id="exampleInputAddress">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPrice">Компания</label>
                                        <input type="text" name="company_name" value="<?php echo e($order->company_name); ?>"
                                               class="form-control"
                                               id="exampleInputPrice">
                                    </div>


                                </div>

                                <div class="col-md-6">
                                    <?php if($order->product_type != '2'): ?>
                                        <label for="del_type">Способ доставки</label>
                                        <div class="form-group" id="del_type">
                                            <input <?php echo e($order->delivery_type == '0' ? 'checked' : ''); ?>  type="radio"
                                                   name="delivery_type" value="0" id="exampleInputDelType2">
                                            <label for="exampleInputDelType1">Самовывоз</label>
                                            <input <?php echo e($order->delivery_type == '1' ? 'checked' : ''); ?>  type="radio"
                                                   name="delivery_type" value="1" id="exampleInputDelType2">
                                            <label for="exampleInputDelType2">Доставка</label>
                                        </div>
                                    <?php endif; ?>
                                    <div class="form-group">
                                        <label for="exampleInputPrice">Цена доставки</label>
                                        <input type="number" name="delivery_fee" step="100" min="0"
                                               value="<?php echo e($order->delivery_fee); ?>"
                                               class="form-control"
                                               id="exampleInputPrice">
                                    </div>

                                    <label for="pay_type">Способ оплаты</label>
                                    <div class="form-group">
                                        <input type="radio" name="pay_type"
                                               <?php echo e($order->pay_type == '0' ? 'checked' : ''); ?>

                                               id="pay_type1" value="0">
                                        <label for="exampleInputPrice">Наличные при получении</label>
                                        <input type="radio" name="pay_type"
                                               <?php echo e($order->pay_type == '1' ? 'checked' : ''); ?>

                                               id="pay_type2" value="1">
                                        <label for="exampleInputPrice">Безналичная оплата </label>
                                        <input type="radio" name="pay_type"
                                               <?php echo e($order->pay_type == '2' ? 'checked' : ''); ?>

                                               id="pay_type3" value="2">
                                        <label for="exampleInputPrice">Онлайн оплата</label>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPrice">Итоговая сумма</label>
                                        <input type="number" name="total_amount" step="100" min="0"
                                               value="<?php echo e($order->total_amount); ?>"
                                               class="form-control"
                                               id="exampleInputPrice">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPrice">Дата</label>
                                        <input type="text" name="date" value="<?php echo e($order->date); ?>"
                                               class="form-control"
                                               id="exampleInputPrice">
                                    </div>
                                </div>
                                <div class="form-group col-md-2 col-md-offset-5 ">

                                    <label for="select_input">Статус заказа</label>
                                    <select class="form-control " name="status" id="select_input">
                                        <option
                                                value="0" <?php echo e((($order->status == "0") ? "selected":"")); ?>>Отказ
                                        </option>
                                        <option
                                                value="1" <?php echo e((($order->status == "1") ? "selected":"")); ?>>Ожидание
                                        </option>
                                        <option
                                                value="2" <?php echo e((($order->status == "2") ? "selected":"")); ?>>Оплачен
                                        </option>
                                    </select>
                                    
                                    <div class="box-footer" style="padding: 10px 0;">
                                        <button type="submit" class="btn btn-primary">Сохранить</button>
                                    </div>
                                </div>
                                </form>

                            </div>

                            <hr>
                            <div class='center'>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="exampleInputDocsEmail">Отправить документы</label>
                                        <div>
                                            <h6>
                                                <?php echo $order->data_email['checked']; ?>

                                                <?php echo e($order->data_email['description']); ?>

                                            </h6>
                                            <form action="<?php echo e(route('sendDocs')); ?>" method="POST"  id="formSendDocs">
                                                <input type="hidden" name="name" value="<?php echo e($order->name); ?>">
                                                <input type="hidden" name="email" value="<?php echo e($order->email); ?>">
                                                <input type="hidden" name="id" value="<?php echo e($order->product_id); ?>">
                                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                <button form="formSendDocs" type="submit" class=" btn btn-sm btn-success"
                                                        id="exampleInputDocsEmail"> <?php echo e($order->data_email['send']); ?> </button>
                                            </form>
                                        </div>
                                    </div>
                                    <?php if($order->pay_type == '2'): ?>
                                        <div class="form-group col-md-6">
                                            <label for="exampleInputDocsEmail">Выставить счет</label>
                                            <div>
                                                <h6>
                                                    <?php echo $order->data_payment['checked']; ?>

                                                    <?php echo e($order->data_payment['description']); ?>

                                                </h6>
                                                <form action="<?php echo e(route('sendRoboCheck')); ?>" method="POST"  id="formSendCheck">
                                                    <?php echo csrf_field(); ?>

                                                <input type="hidden" name="name" value="<?php echo e($order->name); ?>">
                                                <input type="hidden" name="email" value="<?php echo e($order->email); ?>">
                                                <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                                                <input type="hidden" name="from_date" value="<?php echo e($order->from_date); ?>">
                                                <input type="hidden" name="to_date" value="<?php echo e($order->to_date); ?>">
                                                <input type="hidden" name="product_id" value="<?php echo e($order->product_id); ?>">
                                                <input type="hidden" name="product_name" value="<?php echo e($order->product_name); ?>">
                                                <input type="hidden" name="product_price" value="<?php echo e($order->product_price); ?>">
                                                <input type="hidden" name="related_price" value="<?php echo e($order->related_price); ?>">
                                                <input type="hidden" name="related_count" value="<?php echo e($order->related_count); ?>">
                                                <input type="hidden" name="related_product" value="<?php echo e($order->related_product); ?>">
                                                <input type="hidden" name="related_product_id" value="<?php echo e($order->related_product_id); ?>">
                                                <input type="hidden" name="delivery_fee" value="<?php echo e($order->delivery_fee); ?>">
                                                <input type="hidden" name="total_amount" value="<?php echo e($order->total_amount); ?>">
                                                <button form="formSendCheck" type="submit" class=" btn btn-sm btn-success"
                                                        id="exampleInputDocsEmail"> <?php echo e($order->data_payment['send']); ?> </button>
                                                </form>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>


                            </div>

                        </div>

                        <div class="box-footer">

                            <div style="float:right;">
                                <a href="<?php echo e(route( 'delete.order' , ['id'=>$order->id])); ?>"
                                   type="submit" title="Удалить заказ"
                                   class="btn  btn-danger btn-xs confirm text-right">
                                    <div class="fa fa-trash-o "></div>
                                </a>
                            </div>

                        </div>


                </div>
                <!-- /.box-body -->


            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>