

<?php $__env->startSection('content'); ?>
    <h2>Статистика</h2>
    <div class="row">
        <div class="col-md-6">

        </div>
        <div class="col-md-6">
            <div id='calendar'></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>