<?php $__env->startSection('content'); ?>
    <div>
        <h2 class="head_title">Пакеты лицензирования</h2>
        <a href="<?php echo e(route( 'create.licensePackage' )); ?>"
           type="submit" class="btn btn-primary link_to_add">Создать</a>

    </div>
    <div class="panel-body">

        <!-- right column -->
        <div class="col-sm-12">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>

            <?php endif; ?>
            <?php if($packages): ?>
                <div>

                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Список</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body no-padding">

                            <table class="table table-condensed">
                                <tr style="color:#269abc">
                                    <th style="width: 10px">ID</th>
                                    <th>Название</th>
                                    <th>Информация</th>
                                    <th>Цена</th>
                                </tr>
                                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td>
                                            <?php echo e($package['id']); ?>

                                        </td>
                                        <td>
                                            <b>
                                                <?php echo e($package['name']); ?>

                                            </b>
                                        </td>
                                        <td>
                                            <?php echo $package['information']; ?>

                                        </td>
                                        <td>
                                            <?php echo e($package['price']); ?>

                                        </td>

                                        <td class="text-right">
                                            <a href="<?php echo e(route( 'edit.licensePackage' , ['id'=>$package['id']])); ?>"
                                               type="submit" class="btn btn-xs btn-primary" style="width:22px">
                                                <div class="fa fa-edit"></div>
                                            </a>
                                            <a href="<?php echo e(route( 'delete.licensePackage' , ['id'=>$package['id']])); ?>"
                                               type="submit" class="btn btn-xs btn-danger confirm">
                                                <div class="fa fa-trash-o "></div>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>