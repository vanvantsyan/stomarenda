

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/')); ?>">Главная</a></li>
                    <li><a href="<?php echo e(url('/packages')); ?>">Пакеты для лицензирования</a></li>
                </ol>
            </div>
        </div>
    </div>
    <section class="physio" style="padding:10px 0 60px 0">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Пакеты для лицензирования  </h1>
                </div>
            </div>
            <div class="row">
                <div class="physio-container-wrap">
                    <div class="physio-bgr-wrap">
                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-6 col-sm-6 padnone">
                                <a href="<?php echo e(url('package/'.$package->id)); ?>">
                                    <div class="physio-container bgrc-dark">
                                        <div class="physio-img-container"><img
                                                    src="<?php echo e(URL::to("$layout_path/images-licensepack/".$package->image)); ?>"
                                                    alt="<?php echo e($package->meta_key); ?>"></div>
                                        <div class="physio-text-container">
                                            <h3><?php echo e($package->name); ?></h3>
                                            <div class="producer"><?php echo $package->information; ?></div>
                                            <div class="lease-time">Аренда в день</div>
                                            <div class="lease-price"><?php echo e($package->price); ?> <i class="fa fa-rub"></i></div>
                                            <span class="read-more" style="float:right">Подробнее <i
                                                        class="fa fa-angle-right"></i></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>


    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site_layout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>