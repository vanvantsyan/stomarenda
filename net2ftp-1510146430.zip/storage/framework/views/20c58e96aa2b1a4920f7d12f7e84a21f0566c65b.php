<?php $__env->startSection('content'); ?>
    <h2>Оборудование</h2>
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
            <?php endif; ?>
            <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Редактировать </h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" method="POST" action="<?php echo e(route('update.product')); ?>" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="exampleInputName">Название</label>
                                <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                                <input name="id" type="hidden" value="<?php echo e($product->id); ?>"/>
                                <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control"
                                       id="exampleInputName" placeholder="Лампа для отбеливания">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputModel">Модель</label>
                                <input type="text" name="model" value="<?php echo e($product->model); ?>" class="form-control"
                                       id="exampleInputModel" placeholder="Lux  25-10">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPrice">Цена</label>
                                <input type="number" name="price" step="100" min="0" value="<?php echo e($product->price); ?>"
                                       class="form-control"
                                       id="exampleInputPrice" placeholder="3500">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputImage">Главное изображение </label>
                                <?php if($product->image): ?>
                                    <div>
                                        <img src="<?php echo e(url('public/images-products/'.$product->image)); ?>"
                                             class="admin_images">
                                    </div>
                                <?php endif; ?>
                                <input type="file" name="image" id="exampleInputImage">
                            </div>
                            <div class="form-group">
                                <label>Другие Изображения</label>
                                <div>
                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('delete.image', ['id' => $image->id ,'path_name' => 'images-products'])); ?>"
                                           title="Delete">
                                            <img class="admin_images"
                                                 src="<?php echo e(url('public/images-products/'.$image->name)); ?>">
                                            <div class="fa fa-remove image-delete">
                                            </div>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <label for="exampleInputMainImage">Добавить </label>
                                <small>Рекомендуемый размер (300 x 260)</small>
                                <input type="file" name="images[]" id="exampleInputMainImage" multiple>
                            </div>
                            <div class="form-group">
                                <label>Файлы</label>
                                <?php if(count($files)): ?>
                                    <small>(<?php echo e(count($files)); ?> имеется)</small><br>
                                <?php else: ?>
                                    <small>(Нету)</small><br>

                                <?php endif; ?>

                                <label for="exampleInputFiles">Добавить </label>
                                <input type="file" name="files[]" id="exampleInputFiles" multiple>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputGroup">Группа</label>
                                <select class="form-control" name="group_id">
                                    <option>--Выберите группу--</option>
                                    <?php $__currentLoopData = $prodGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($prodGroup->id); ?>" <?php echo e((($product->group_id == $prodGroup->id) ? "selected":"")); ?>><?php echo e($prodGroup->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputGroup">Производитель</label>
                                <select class="form-control" name="manufacturer_id">
                                    <option>--Выберите производителя--</option>
                                    <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($manufacturer->id); ?>" <?php echo e((($product->manufacturer_id == $manufacturer->id) ? "selected":"")); ?>><?php echo e($manufacturer->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputMetadesc">Мета-Описание</label>
                                <input type="text" name="meta_desc" value="<?php echo e($product->meta_description); ?>"
                                       class="form-control" id="exampleInputMetadesc" placeholder="Описание продукта">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputMetakeys">Мета-key</label>
                                <input type="text" name="meta_key" value="<?php echo e($product->meta_key); ?>"
                                       class="form-control" id="exampleInputMetakeys" placeholder="Ключевые слова">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputDesc">Описание</label>
                                <textarea class="form-control" name="description" id="froala-editor"
                                          placeholder="Описание продукта"><?php echo e($product->description); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputAttributes"> Характеристика </label>
                                <textarea class="form-control" name="attributes" id="froala-editor"
                                          placeholder="Характеристика продукта"><?php echo e($product->attributes); ?></textarea>
                            </div>


                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Сохранить</button>
                        </div>

                    </form>
                </div>
                <!-- /.box-body -->


            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>