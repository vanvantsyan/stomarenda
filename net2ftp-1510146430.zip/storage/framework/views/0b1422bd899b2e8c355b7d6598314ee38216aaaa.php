

<?php $__env->startSection('content'); ?>
    <div>
        <h2 class="head_title">Оборудование для лицензирования</h2>
        <a href="<?php echo e(route( 'create.licenseProducts' )); ?>"
           type="submit" class="btn btn-primary link_to_add">Создать</a>

    </div>
    <div class="panel-body">

        <!-- right column -->
        <div class="col-sm-12">
            <?php if($products): ?>

                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Список</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body no-padding">
                            <table class="table table-condensed">
                                <tr style="color:#269abc">
                                    <th style="width: 10px">ID</th>
                                    <th>Название</th>
                                    <th>Мета-описание</th>
                                    <th>Мета-ключ</th>
                                    <th>Кол-во</th>
                                </tr>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td>
                                            <?php echo e($key+1); ?>

                                        </td>
                                        <td>
                                            <b>
                                                <?php echo e($product['type_name']); ?>

                                            </b>
                                        </td>
                                        <td>
                                            <?php echo e($product['meta_description']); ?>

                                        </td>
                                        <td>
                                            <?php echo e($product['meta_key']); ?>

                                        </td>
                                        <td>
                                            <?php echo e(count(json_decode($product['product_info']))); ?>

                                        </td>
                                        <td class="text-right">
                                            <a href="<?php echo e(route( 'edit.licenseProduct' , ['id'=>$product['id']])); ?>"
                                               type="submit" class="btn btn-xs btn-primary">
                                                <div class="fa fa-edit"></div>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </table>
                        </div>
                    </div>

            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>