<?php $__env->startSection('content'); ?>


    <!-- Main content -->
    <section class="content">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="box-header">
                <h2 class="head_title"> Производители</h2>
                <a href="<?php echo e(route( 'create.manufacturer' )); ?>"
                   type="submit" class="btn btn-primary link_to_add">Создать</a>
            </div>
            <div class="box-body">
                <table class="table table-condensed">
                    <tr style="color:#269abc">
                        <th style="width: 10px">ID</th>
                        <th>Название</th>
                        <th>Страна</th>
                        <th style="width: 80px"></th>
                    </tr>
                    <?php if($manufacturers): ?>
                        <?php $__currentLoopData = $manufacturers->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td>
                                    <?php echo e($manufacturer['id']); ?>

                                </td>
                                <td>
                                    <b>
                                        <?php echo e($manufacturer['name']); ?>

                                    </b>
                                </td>
                                <td>
                                    <?php echo e($manufacturer['country']); ?>

                                </td>

                                <td class="text-right">
                                    <a href="<?php echo e(route( 'edit.manufacturer' , ['id'=>$manufacturer['id']])); ?>"
                                       type="submit" class="btn btn-xs btn-primary" style="width:22px">
                                        <div class="fa fa-edit"></div>
                                    </a>
                                    <a href="<?php echo e(route( 'delete.manufacturer' , ['id'=>$manufacturer['id']])); ?>"
                                       type="submit" class="btn btn-xs btn-danger confirm">
                                        <div class="fa fa-trash-o "></div>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </table>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>