@extends('site_layout.front')

@section('content')

    <style>


        .full-height {
            height: 500px;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 36px;
            padding: 20px;
        }
    </style>

    <div class="flex-center position-ref full-height">
        <div class="content">
            <div class="title" style="color:grey">
                Извините , вами запрашиваемая страница не найдена.
            </div>
        </div>
    </div>


@endsection