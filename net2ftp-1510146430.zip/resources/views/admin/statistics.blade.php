@extends('admin_layouts.admin')

@section('content')
    <h2>Статистика</h2>
    <div class="row">
        <div class="col-md-6">

        </div>
        <div class="col-md-6">
            <div id='calendar'></div>
        </div>
    </div>
@endsection
