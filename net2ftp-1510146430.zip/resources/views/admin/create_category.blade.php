@extends('admin_layouts.admin')

@section('content')

    <h2>Пакеты</h2>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6">

                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Добавить категорию</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="{{route('add.categories')}}" method="POST">
                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>

                        <div class="box-body">
                            <div class="form-group">
                                <label for="exampleInputCategories">Название</label>
                                <input type="text" name="category_name" class="form-control" id="exampleInputCategories"
                                       placeholder="Category name">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputMetaDescription">Мета-описание</label>
                                <input type="text" name="meta-desc" class="form-control" id="exampleMetaDescription"
                                       placeholder="Текс описывающий категорию.">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputMetaKey">Мета-key</label>
                                <input type="text" name="meta-key" class="form-control" id="exampleMetaKey"
                                       placeholder="Ключевые слова">
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Добавить</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </section>
@endsection
