@extends('admin_layouts.admin')

@section('content')
    <h2>Категории</h2>
    <div style="width:70%;">
        <!-- general form elements -->
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Редактировать категорию</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <div class="box-body">

                <form role="form" action="{{route('update.category')}}" method="POST">
                    <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                    <input name="id" type="hidden" value="{{$category->id}}"/>

                    <div class="form-group">
                        <label for="exampleInputCategories">Название категории</label>
                        <input type="text" name="category_name" class="form-control" id="exampleInputCategories"
                               value="{{$category->name}}" placeholder="Category name">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputMetaDescription">Мета-описание</label>
                        <input type="text" name="meta-desc" class="form-control" id="exampleMetaDescription"
                               value="{{$category->meta_description}}" placeholder="Meta-Description">
                    </div>
                    <div class="form-group">
                        <label for=" exampleMetaKey">Мета-key</label>
                        <input type="text" name="meta-key" class="form-control" id="exampleMetaKey"
                               value="{{$category->meta_key}}" placeholder="Meta-Key">
                    </div>
                    <button type="submit" class="btn btn-primary">Сохранить</button>
                </form>

            </div>
            <!-- /.box-body -->

        </div>
    </div>


    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif


@endsection
